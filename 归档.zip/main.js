let a = 114514
let b = 1919810
let c = [1,2,3]
console.log(a,b,c)